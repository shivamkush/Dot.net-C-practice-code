﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {

        static float avgofNumber(int a, int b, int c)
        {
            float sum = (a + b + c)/3;
            return sum;
        }

        static float avgofNumber(int a, int b)
        {
            return (a + b) / 2;
        }
        static void Main(string[] args)
        {



            //  double age =Convert.
            //  char oneC = 'K';

            ////  float fnum1 = age;

            //  Console.WriteLine(age);

            //  Double persent = 56.8;
            //  float fnum = 57.33f;
            //  Boolean good = true;
            //  Console.WriteLine("My name will visible in 3 second");
            // string name = Console.ReadLine();
            //  System.Threading.Thread.Sleep(5000);
            //  Console.Write("Its "+ name);
            //  System.Threading.Thread.Sleep(5000);
            //  Console.WriteLine("my age is " + age +"is he good man"+good);
            //  //Console.ReadLine();

            //  Console.WriteLine(oneC);

            //  Console.WriteLine(persent);

            //  Console.WriteLine(fnum);



            //  Console.WriteLine("");
            //  System.Threading.Thread.Sleep(5000);

            //  Console.WriteLine("time over");

            //  Console.ReadKey();

            //Console.WriteLine("What is your name?");

            //string name = Console.ReadLine();

            //Console.WriteLine("Hi " + name + " How are you?");

            //Console.WriteLine("What is your age?");

            //string age = Console.ReadLine();

            //Console.WriteLine("Ok your actual age is "+age+" but I'll tell her your age "+(Convert.ToInt32(age) - 3) +" year");

            //Console.WriteLine(22 >= 22);
            //Console.WriteLine(22 >= 22 != 10 > 20);

            //Console.ReadKey();

            //Double a = Math.Sqrt(12);
            //Console.WriteLine(a);

            //int b = Math.Max(21,51);

            //Console.WriteLine(b);

            //string city = "farrukhabad";

            //Console.WriteLine($"your city is"+city);

            //string name = "Mark";
            //var date = DateTime.Now;

            //// Composite formatting:
            //Console.WriteLine("Hello, {0}! This year is {1}, it's {2:HH:mm} now.", "Shivam", date.DayOfWeek, date);
            //// String interpolation:
            //Console.WriteLine($"Hello, {name}! Today is {date.DayOfWeek}, it's {date:HH:mm:ss} now.");

            //Console.WriteLine(name);
            //-------------------------------------------------------
            //Console.WriteLine("Please enter your age");
            //string age = Console.ReadLine();
            //if (Convert.ToInt32(age) >= 18)

            //{
            //    Console.WriteLine("You can drive car here");
            //}

            //else
            //{
            //    Console.WriteLine("You can not drive car here");
            //}
            //-----------------------------------------------------------

            //int i = 0;

            //while (i < 500)
            //{
            //    Console.WriteLine(i);
            //    i++;
            //}

            //-------------------------------------------------------

            //int i = 0;

            //do
            //{
            //    Console.WriteLine(i+1); Console.WriteLine("Do while");
            //    i++;
            //}
            //while (i < 5)

            //------------------------------------------------------
            //Console.WriteLine("Please enter a number");
            //string i = Console.ReadLine();
            //int num = Convert.ToInt32(i);
            //for (int j = 0; j <= num; num--)
            //{
            //    if (num == 1)
            //    {
            //        continue;
            //    }
            //    Console.WriteLine(num);


            //}

           float avg = avgofNumber(5, 5, 5);
            float avg1 = avgofNumber(4,4);

            Console.WriteLine(avg);
            Console.WriteLine(avg1);
            Console.ReadKey();
           
       
        }
    }
}
